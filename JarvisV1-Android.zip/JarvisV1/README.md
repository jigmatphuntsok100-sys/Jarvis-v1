# JARVIS v1 — Android

A starter Android JARVIS-style voice assistant.

## Build
Open this folder in Android Studio, let Gradle sync, then Run on an Android phone.

## Included
- Futuristic dark HUD starter
- Speech recognition
- Text-to-speech
- Open YouTube/Google
- Basic call command handling
- Extensible command router

Next upgrade: connect an AI backend and add richer Android automation.
