package com.example.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import android.graphics.Color
import java.util.*

class MainActivity : android.app.Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private val REQ_SPEECH = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(Color.rgb(5,7,10))
        }
        val title = TextView(this).apply {
            text = "J A R V I S"
            textSize = 30f
            setTextColor(Color.CYAN)
            gravity = 17
        }
        status = TextView(this).apply {
            text = "SYSTEM ONLINE\nAwaiting command..."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = 17
            setPadding(0, 60, 0, 60)
        }
        val talk = Button(this).apply {
            text = "🎙  TALK TO JARVIS"
            textSize = 18f
            setOnClickListener { listen() }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(talk)
        setContentView(layout)
    }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Yes, sir?")
        startActivityForResult(i, REQ_SPEECH)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SPEECH || resultCode != RESULT_OK) return
        val command = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
        status.text = "COMMAND RECEIVED\n$command"
        handle(command.lowercase(Locale.getDefault()))
    }

    private fun handle(command: String) {
        when {
            command.contains("open youtube") -> openUrl("https://www.youtube.com")
            command.contains("open google") -> openUrl("https://www.google.com")
            command.contains("call ") -> {
                val number = command.substringAfter("call ").trim()
                speak("I can place calls when a phone number is provided.")
                if (number.matches(Regex("[+0-9 ()-]{7,}"))) {
                    if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
                        requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 9)
                    else startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")))
                }
            }
            command.contains("hello") || command.contains("hi jarvis") ->
                speak("Good evening. JARVIS systems are online.")
            else -> speak("I heard: $command. AI integration can be connected in the next build.")
        }
    }

    private fun openUrl(url: String) {
        speak("Opening now.")
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun speak(text: String) {
        status.text = "JARVIS\n$text"
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            tts.setSpeechRate(0.92f)
        }
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}
